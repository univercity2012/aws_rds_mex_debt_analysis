import dash
import dash_core_components as dcc
import dash_html_components as html
import dash_table
from dash.dependencies import Input, Output, State
import pandas as pd
from datetime import datetime as dt
import time
from pandas import read_sql, DataFrame, to_datetime
from numpy import isnan
import json
from sqlalchemy import create_engine

################################################################################
# database class
################################################################################
class databaseInit():
    database_name = None
    database_user = None
    database_password = None
    database_host = None
    database_port = None

    def __init__(self, property, create_table=False):
        self.database_name = property['database_name']
        self.database_user = property['database_user']
        self.database_password = property['database_password']
        self.database_host = property['database_host']
        self.database_port = property['database_port']
        
    def return_connection_string(self):
            try:
                connection_string = 'mysql+pymysql://' + self.database_user + ':' + self.database_password + '@' + self.database_host + ':' + self.database_port + '/' + self.database_name
                print(connection_string)
                return connection_string
            except Exception as e:
                raise ValueError(f'return_connection_string(): failed, please check the connection string: {e}')
        
    def connection_object(self):
        try:
            connection_string = self.return_connection_string()
            engine = create_engine(connection_string).connect()
            return engine
        except Exception as e:
            raise ValueError(f'connection_object(): failed to connect to database: {e}')

################################################################################
# initialization database
################################################################################
db_prop = {
        "database_name" : "xxx",
        "database_user" : "xxx",
        "database_password" : "xxx",
        "database_host" : "xxx",
        "database_port" : "xxx"}
mydb = databaseInit(db_prop)
engine = mydb.connection_object()

################################################################################
# Database Query Util Functions
################################################################################
def get_sector():
    df_table = pd.DataFrame()
    try:
        df_table = read_sql('sector', con=engine)
    except Exception as e:
        print(e)
    return df_table

def get_maturity():
    df_table = pd.DataFrame()
    try:
        df_table = read_sql('query_date', con=engine)
    except Exception as e:
        print(e)
    return df_table
def get_bond_type():
    df_table = pd.DataFrame()
    try:
        df_table = read_sql('bond_type', con=engine)
    except Exception as e:
        print(e)
    return df_table

def get_mx_debt(query_date, bond_type, sector):
    debt_table = pd.DataFrame()
    if sector is None or sector == 'all': 
        sector = '*'
    d = {'sector': sector,
         'query_date': query_date.strftime('%Y-%m-%d'),
         'bond_type':bond_type}
    if sector is '*':
        query = "select * from debt where bond_type='{bond_type}' AND query_date>='{query_date}' GROUP BY maturity_date ASC".format(**d)
    else:
        query = "select id,bond_type,maturity_date,{sector} from debt where bond_type='{bond_type}' AND query_date>='{query_date}' GROUP BY maturity_date ASC".format(**d)
    try:
        debt_table = read_sql(query, con=engine, index_col='id')
    except Exception as e:
        print(e)
    return debt_table
 
################################################################################
# Plotly Dash Applicatoin
################################################################################
app = dash.Dash(__name__)
app.css.append_css({
    "external_url": "https://codepen.io/chriddyp/pen/bWLwgP.css"
})

################################################################################
# Initialization of the Web App
################################################################################
df_maturity = get_maturity().to_dict('records')
maturity_options = []
for obj in df_maturity:
    for key, value in obj.items():
        if key == 'id':
            continue
        else:
            d = {'label': value, 'value': value}
            maturity_options.append(d)

df_bond_type = get_bond_type().to_dict('records')
bond_type_options = []
for obj in df_bond_type:
    for key, value in obj.items():
        if key == 'id':
            continue
        else:
            d = {'label': value, 'value': value}
            bond_type_options.append(d)

df_sector_type = get_sector().to_dict('records')   
sectors_options = []
for obj in df_sector_type:
    for key, value in obj.items():
        if key == 'id':
            continue
        else:
            d = {'label': value, 'value': value}
            sectors_options.append(d)

debt_table = get_mx_debt(maturity_options[0]['value'], bond_type_options[0]['value'],sectors_options[0]['value'])

################################################################################
# Web App Layout
################################################################################
app.layout = html.Div([
    dcc.DatePickerSingle(
            id='my-date-picker-single',
            min_date_allowed=dt(1995, 1, 1),
            max_date_allowed=dt(2090, 12, 31),
            initial_visible_month=maturity_options[0]['value'],
            date=maturity_options[0]['value']
        ),
        html.Div(id='output-container-date-picker-single'),
    dcc.Dropdown(
        id='bond-type',
        value=bond_type_options[0]['value'],
        options=bond_type_options,
        style={'height': '30%', 'width': '28%'}
    ),
    dcc.Dropdown(
        id='sectors',
        value='all',
        options=sectors_options,
        style={'height': '30%', 'width': '28%'}
    ),
    dash_table.DataTable(id='datatable', data=debt_table.to_dict('records')),
    html.Div(id='output')
])

@app.callback(
    dash.dependencies.Output('output-container-date-picker-single', 'children'),
    [dash.dependencies.Input('my-date-picker-single', 'date')])

@app.callback(Output('output', 'children'),
              [dash.dependencies.Input('my-date-picker-single', 'date'),
              Input('bond-type', 'value'),
              Input('sectors', 'value')],
              [State('datatable', 'derived_virtual_data')])
def update_output(input1, input2, input3, derived_virtual_data):
    maturity_date = dt.strptime(input1, "%Y-%m-%d").date()
    df = get_mx_debt(maturity_date, input2, input3)
    return  dash_table.DataTable(
        id='output-state',
        columns=[{"name": i, "id": i} for i in df.columns],
        data=df.to_dict("rows"),
    )

################################################################################
# Web App Entry Point
################################################################################
if __name__ == '__main__':
    app.run_server(port=8080, host='0.0.0.0')