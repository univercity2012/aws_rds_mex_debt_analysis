import re
import os
import sys
import atexit
import pandas as pd
from pandas import read_sql, DataFrame, to_datetime
from datetime import datetime
import requests

################################################################################
# Tool: Import pymysql module for mysql client functionality
################################################################################
import pymysql

################################################################################
# Tool: Import BeautifulSoup module for pullling data out of website
################################################################################
from bs4 import BeautifulSoup

################################################################################
# Tool: Import selenium module for web interaction functionality
################################################################################
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.select import Select
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.common.exceptions import StaleElementReferenceException

################################################################################
# Tool: Import sqlalchemy module for DB functionality
################################################################################
from sqlalchemy import *
#from sqlalchemy.databases import *
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.dialects.mysql import FLOAT
from sqlalchemy.orm import scoped_session,sessionmaker
from sqlalchemy.orm import sessionmaker, relationship
from sqlalchemy import event, DDL
from sqlalchemy import (
    Column,
    Integer,
    String,
    Boolean,
    ForeignKey,
    DateTime,
    Date,
    Sequence,
    Float
)

################################################################################
# Define the required table class
################################################################################
Base = declarative_base()

#todo: the relation between tables should be establish to ensure data integrity
class QueryDate(Base):
    __tablename__ = 'query_date'
    id = Column(Integer, primary_key=True, autoincrement=True)
    date = Column(Date)

class BondType(Base):
    __tablename__ = 'bond_type'
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(50))

class Debt(Base):
    __tablename__ = 'debt'
    id = Column(Integer, primary_key=True, autoincrement=True)
    bond_type = Column(String(50))
    base_currency = Column(String(3))
    reporting_currency = Column(String(3))
    query_date = Column(Date)
    maturity_date = Column(Date)
    repos = Column(Float)
    guarantees_received = Column(Float)
    banking_sector = Column(Float)
    securities_held = Column(Float)
    pension_funds = Column(Float)
    investment_funds = Column(Float)
    insurance_surety_companies = Column(Float)
    other_residents = Column(Float)
    residents = Column(Float)
    non_residents = Column(Float)
    total_outstanding = Column(Float)

class Sector(Base):
    __tablename__ = 'sector'
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(30))

################################################################################
# Define the DB Util class for db transaction functionality
################################################################################
class dbutil():
    database_name = None
    database_user = None
    database_password = None
    database_host = None
    database_port = None
    
    # TODO: read the bond type mappig from configuartion file
    bond_type_dic = {
                        'BI': 'Cetes-BI',
                        'LD': 'Bondes-D',
                        'S': 'Non-Stripped-Udibonos',
                        'S0': 'Non-Stripped-Udibonos',
                        'SP': 'Stripped-Udibonos',
                        'M': 'Non-Stripped-Bonos',
                        'M0': 'Non-Stripped-Bonos',
                        'MP': 'Stripped-Bonos',
                    }
    currency_dic = {
                        'pesos': 'MXN',
                        'udis': 'MXV'
                    }
       
################################################################################
# Constructor to set the db property
################################################################################
    def __init__(self, property, create_table=False):
        self.database_name = property['database_name']
        self.database_user = property['database_user']
        self.database_password = property['database_password']
        self.database_host = property['database_host']
        self.database_port = property['database_port']

################################################################################
# Return a connection string for the database
################################################################################
    def return_connection_string(self):
        try:
            connection_string = 'mysql+pymysql://' + self.database_user + ':' + self.database_password + '@' + self.database_host + ':' + self.database_port + '/' + self.database_name
            print(connection_string)
            return connection_string
        except Exception as e:
            raise ValueError(f'return_connection_string(): failed, please check the connection string: {e}')

################################################################################
# Connect to database
################################################################################    
    def connection_object(self):
        try:
            connection_string = self.return_connection_string()
            engine = create_engine(connection_string).connect()
            return engine
        except Exception as e:
            raise ValueError(f'connection_object(): failed to connect to database: {e}')

################################################################################
# Check if query date exist already
################################################################################      
    def check_query_date_exist(self, query_date, engine):
        status = False # exist
        try:
            new_query_date = QueryDate()
            new_query_date.date = query_date
            Session = sessionmaker(bind=engine)
            this_session = Session()
            ret = this_session.query(exists().where(QueryDate.date==query_date)).scalar()
            if ret is False:
                this_session.add(new_query_date)
                this_session.commit()
                status = True
            this_session.close()
        except Exception as e:
            raise ValueError(f'check_query_date_exist(): failed to insert new query date {query_date}: {e}')
        return status

################################################################################
# Check if bond type exist already
################################################################################ 
    def check_bond_type_exist(self, bond_type_name, engine):
        status = False # exist
        try:
            new_bond_type = BondType()
            new_bond_type.name = bond_type_name
            Session = sessionmaker(bind=engine)
            this_session = Session()
            ret = this_session.query(exists().where(BondType.name==bond_type_name)).scalar()
            if ret is False:
                this_session.add(new_bond_type)
                this_session.commit()
                status = True
            this_session.close()
        except Exception as e:
            raise ValueError(f'check_bond_type_exist(): failed to insert new bond type {bond_type_name}: {e}')
        return status

################################################################################
# Intial the sector table with initial values
################################################################################         
    def insert_initial_sectors(self, sector_list, engine):
        status = False # exist
        try:
            Session = sessionmaker(bind=engine)
            this_session = Session()
            for sector in sectors: 
                ret = this_session.query(exists().where(Sector.name==sector)).scalar()
                if ret is False:
                    new_sector_type = Sector()
                    new_sector_type.name = sector
                    this_session.add(new_sector_type)
                this_session.commit()
                this_session.close()
        except Exception as e:
            raise ValueError(f'check_bond_type_exist(): failed to insert new sector type {sector_list}: {e}')
        return status

################################################################################
# Intial the sector table with initial values
################################################################################         
    def check_bond_type_query_date_exist(self, bond_type, query_date, engnie):
        debt_table = pd.DataFrame()
        d = {'query_date': query_date,
             'bond_type':bond_type}
        query = "select id, bond_type from debt where bond_type='{bond_type}' AND query_date='{query_date}'".format(**d)
        try:
            debt_table = read_sql(query, con=engine, index_col='id')
        except Exception as e:
            print(e)
        if debt_table.empty:
            return True
        else:
            return False
        
################################################################################
# Try to commit the debt table for each bond type
################################################################################        
    def try_commit(self, table_df, querydate, currency, fx_rate, engine):
        try:
            query_date = datetime.strptime(querydate, "%d/%m/%Y").date()
            objects_to_commit = []
            query_date_exist = False
            bond_type_exist = False
            sector_exist = False
            current_bond_type = ""
            reporting_currency = 'pesos' #TODO: read from config file 
            try:
                for index, row in table_df.iterrows():
                    obj = Debt()
                    rec_json = row.to_dict()
                    if query_date_exist == False:
                        query_date_exist = self.check_query_date_exist(query_date, engine)
                    try:
                        obj.bond_type = self.bond_type_dic[rec_json['instrument_type']]
                        current_bond_type = obj.bond_type
                        if bond_type_exist == False:
                            bond_type_exist = self.check_bond_type_exist(obj.bond_type, engine)
                    except Exception as e:
                        if (rec_json['instrument_type']=='-'):
                            continue
                        else:
                            print (f"Failed to mapped bond type : {rec_json['instrument_type']}, process continue")
                            continue
                    obj.query_date = query_date
                    obj.maturity_date = datetime.strptime(rec_json['maturity_date'], "%d/%m/%Y").date()
                    obj.base_currency = self.currency_dic[currency]
                    obj.reporting_currency = self.currency_dic['pesos'] #TODO: make this configurable
                    obj.repos =  float(rec_json['repos'].replace(',','')) * fx_rate
                    obj.guarantees_received =  float(rec_json['guarantees_received'].replace(',','')) * fx_rate
                    obj.banking_sector =  float(rec_json['banking_sector'].replace(',','')) * fx_rate
                    obj.securities_held =  float(rec_json['securities_held'].replace(',','')) * fx_rate
                    obj.pension_funds =  float(rec_json['pension_funds'].replace(',','')) * fx_rate
                    obj.investment_funds =  float(rec_json['investment_funds'].replace(',','')) * fx_rate
                    obj.insurance_surety_companies =  float(rec_json['insurance_surety_companies'].replace(',','')) * fx_rate
                    obj.other_residents =  float(rec_json['other_residents'].replace(',','')) * fx_rate
                    obj.residents =  float(rec_json['residents'].replace(',','')) * fx_rate
                    obj.non_residents =  float(rec_json['non_residents'].replace(',','')) * fx_rate
                    obj.total_outstanding =  float(rec_json['total_outstanding'].replace(',','')) * fx_rate
                    objects_to_commit.append(obj)
            except Exception as e:
                raise ValueError(f'row {row} can not be mapped: {e}')
            # check if the given bond type and query date exit
            if self.check_bond_type_query_date_exist(current_bond_type, query_date, engine):
                if len(objects_to_commit):
                    Session = sessionmaker(bind=engine)
                    this_session = Session()
                    this_session.bulk_save_objects(objects_to_commit)
                    this_session.commit()
                    this_session.close()
                else:
                    raise ValueError('empty record')
        except Exception as e:
            raise ValueError(f'try_commit(): failed to: {e}') 

# TODO: read the headers & sectors from a configuartion file
sectors = ['repos','guarantees_received','banking_sector','securities_held','pension_funds','investment_funds','insurance_surety_companies','other_residents','residents','non_residents','total_outstanding']
headers = ['instrument_type','maturity_date'] + sectors

################################################################################
# Get the content of the table and store in dataframe
################################################################################ 
def get_table(table):
    try:
        data = []
        table_body = table.find('tbody')
        rows = table_body.find_all('tr')
        for row in rows:
            cols = row.find_all('td')
            cols = [ele.text.strip() for ele in cols]
            data.append([ele for ele in cols if ele])
        df = pd.DataFrame(data, columns=headers)
    except:
        raise ValueError('get_table(): failed to get data') 
    return df

def getBbondtype(soup, index):
    table = None
    table_element_name = "_id0:tablaContenidoDetalles:{}:tablaDetallesSectorizacion".format(index)
    table = soup.find('table', attrs={'id':table_element_name})
    return table
    
def getCurrency(soup, index):
    currency = None
    table = None
    table_element_name = "_id0:tablaContenidoDetalles:{}:tablaDetallesSectorizacion".format(index)
    table = soup.find('table', attrs={'id':table_element_name})
    currency_elems = soup.findAll('span', attrs={'class':'subtituloscont'})
    for item in currency_elems:
        try:
            currency = re.findall(r'Amount in millions of (.*?) at face value', item.text)
            if len(currency):
                break
        except:
            continue
    return currency[0].strip()
    
def getMXVMXNFxRate(hist_date):
    #uri = 'https://fx-rate.net/historical/?c_input=MXV&cp_input=MXN&date_to_input=2014-06-02'
   
    fx_rate = None
    query_date = datetime.strptime(hist_date, "%d/%m/%Y").date()
    hist_date_str = query_date.strftime("%Y-%m-%d")
    uri = f'https://fx-rate.net/historical/?c_input=MXV&cp_input=MXN&date_to_input={hist_date_str}'
    try:
        resp = requests.get(uri)
        soup = BeautifulSoup(resp.text,'html.parser')
        currency_elems = soup.findAll('td', attrs={'class':'result'})
        for item in currency_elems:
            try:
                fx_rate = re.findall(r'\d+\.\d+', item.text)
                if len(fx_rate):
                    break
            except:
                continue
    except requests.HTTPError as e:
        print(PipelineServiceError("{reason}".format(reason=e)))
    return fx_rate[0].strip()
    
################################################################################
# Get the required data for the given maturity date
################################################################################
def click_report_link(query_date, link_obj):
    try:
        link_obj.click()
        try:
            soup = BeautifulSoup(driver.page_source,'html.parser')
            title = soup.find('table', attrs={'id':'_id0:paginaMarco'}).tbody.tr.td.span.text
            query_date_str = re.search(r'\d{2}/\d{2}/\d{4}', title)
            table = soup.find('table', attrs={'id':'_id0:tablaContenidoDetalles'})
            table_body = table.find('tbody')
            rows = table_body.find_all('tr')
            
            table_count = 0
            total_table = driver.find_elements_by_id('_id0:tablaContenidoDetalles:tablaDetallesSectorizacion:totalCirculacion')
            for i in total_table:
                table_count = table_count + 1
            currency = 'pesos'
            # try to store table in the database
            for x in range(0, table_count):
                fx_rate = "1.0"
                table = getBbondtype(soup, x)
                if table:
                    table_df = get_table(table)
                    if (table_df['instrument_type'][0] == 'S'):
                        currency = 'udis'
                        fx_rate = getMXVMXNFxRate(query_date)
                    mydb.try_commit(table_df, query_date, currency, float(fx_rate), engine)
                else:
                    print (f"click_report_link() failed to get the expected table or base currency.")
        except Exception as e:
            raise ValueError(f'Data parsing or database commit error: {e}')
    except StaleElementReferenceException:
        print ("Unexpected error:" + sys.exc_info()[0])

def get_query_dates(driver, element):
    date_list = [] 
    driver.find_element_by_name(element)
    options = [x for x in driver.find_elements_by_tag_name("option")]
    for element in options:
        date_list.append(element.get_attribute("value"))
    return date_list

################################################################################
# main
################################################################################    
if __name__ == '__main__':
    # requirement sudo pip install -U chromedriver-binary selenium
    # /usr/local/bin/chromedriver-path 
    # sudo chmod a+x `/usr/local/bin/chromedriver-path`/chromedriver
   
################################################################################
# Global variables
################################################################################
    status = 0
    CREATE_ALL_TABLE = True #once the talbe is created we can set it to False
    
################################################################################
# initialization database
################################################################################
    db_prop = {
                "database_name" : "xxxx",
                "database_user" : "xxxx",
                "database_password" : "xxxx",
                "database_host" : "xxxx",
                "database_port" : "xxxx"}
    try:
################################################################################
# Instantiate a DB util class
################################################################################
        mydb = dbutil(db_prop)
        
################################################################################
# Initiate a connection to AWS Relational Database Service (RDS)
################################################################################
        engine = mydb.connection_object()
        
################################################################################
# Create initial tables
################################################################################
        if (CREATE_ALL_TABLE):
            Base.metadata.create_all(bind=engine)
################################################################################
# Insert initial sector data
################################################################################
            mydb.insert_initial_sectors (sectors, engine)
        
################################################################################
# Web Scraping
################################################################################
        
        # Specific Google Chrome library path
        CHROMEDRIVER_PATH = os.path.join(os.popen('/usr/local/bin/chromedriver-path').read().rstrip(), 'chromedriver')
        options = Options()
        options.headless = True
         # Instantiate Selinium Google Chrome Driver
        driver = webdriver.Chrome(CHROMEDRIVER_PATH, chrome_options=options)
        @atexit.register
        def quit_chrome():
            driver.quit()
            status = 1
        
        url = 'http://www.anterior.banxico.org.mx/valores/LeePeriodoSectorizacionValores.faces?BMXC_claseIns=GUB&BMXC_lang=en_MX'
        # First vistit to the webpage to get a list of query date 
        response = driver.get(url)
        date_list = get_query_dates(driver, '_id0:selectOneFechaIni')
        latest_date_index = len(date_list)
        
        # get last 30 days for populating the database with some data
        # In practise you may want to schedule a cron job to check once a day
        num_of_days = 30
        
        start_date_index = latest_date_index - num_of_days
        
        #make sure the start query date is before the last query date
        if start_date_index >= 0:
            
            #--------------------------------------------------------------------------------
            # for each date x in the given date range, try to get visit the main
            # data and grab the data. I am using this approch becuase diver.back()
            # doesn't work.
            #-------------------------------------------------------------------------------
            for x in range(latest_date_index-1, start_date_index, -1):
                print (f"processing date from {date_list[start_date_index]} to {date_list[x]} ...")
                try:
                    response = driver.get(url)
                    from_date_element = WebDriverWait(driver,10).until(
                        lambda driver: driver.find_element_by_name('_id0:selectOneFechaIni')
                    )
                    ActionChains(driver).move_to_element(from_date_element).click().send_keys(date_list[x]).perform()
                    to_date_element = WebDriverWait(driver,10).until(
                        lambda driver: driver.find_element_by_name('_id0:selectOneFechaFin')
                    )
                    ActionChains(driver).move_to_element(to_date_element).click().send_keys(date_list[x]).perform()
                    results_elements = driver.find_element_by_css_selector("input[type='submit']").click()
                    driver.implicitly_wait(3)
                    colSize = 0
                    rowSize = 0
        
                    tableBody = driver.find_element_by_xpath("//table[@id='_id0:tablaDetallesSectorizacion']/tbody")
                    # store the date, link obj as key value pairs
                    date_obj_dict = []
                    list_links = driver.find_elements_by_class_name('link02')
                    for i in list_links:
                        query_date_str = re.search(r'\d{2}/\d{2}/\d{4}', i.text)
                        d = {'key': query_date_str.group(), 'value': i}
                        date_obj_dict.append(d)
                    # for each clickable link obj, call click_report_link()
                    # to scrap the require data
                    for obj in date_obj_dict:
                        print(query_date_str)
                        click_report_link (obj['key'], obj['value'])
                except TimeoutException:
                    print(driver.page_source)
                    print('Error, the server not responding')
                    status = 1
    except Exception as e:
        print(f'{e}')
        status = 1
    exit(status)